<?php

/**
 * @author TJ Draper <tj@buzzingpixel.com>
 * @copyright 2017 BuzzingPixel, LLC
 * @license https://buzzingpixel.com/software/ansel-ee/license
 * @link https://buzzingpixel.com/software/ansel-ee
 */

?>

<div class="box table-list-wrap">
	<? /* Get inline CP alerts */ ?>
	<?=ee('CP/Alert')->getAllInlines()?>
</div>
