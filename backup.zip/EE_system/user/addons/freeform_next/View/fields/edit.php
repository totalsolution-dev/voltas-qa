<div class="<?php echo version_compare(APP_VER, '4.0.0', '<') ? 'box' : '' ?>">
<?php $this->embed('ee:_shared/form')?>
</div>
