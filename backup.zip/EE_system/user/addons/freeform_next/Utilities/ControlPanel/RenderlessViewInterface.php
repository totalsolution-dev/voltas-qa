<?php

namespace Solspace\Addons\FreeformNext\Utilities\ControlPanel;

interface RenderlessViewInterface
{
}
