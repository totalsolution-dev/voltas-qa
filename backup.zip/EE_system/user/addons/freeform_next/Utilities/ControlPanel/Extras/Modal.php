<?php

namespace Solspace\Addons\FreeformNext\Utilities\ControlPanel\Extras;

abstract class Modal
{
    /**
     * Combines all variables and adds the Modal to the CP
     */
    public abstract function compile();
}
