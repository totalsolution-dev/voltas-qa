<?php

namespace Solspace\Addons\FreeformNext\Library\Exceptions\Connections;

use Solspace\Addons\FreeformNext\Library\Exceptions\FreeformException;

class ConnectionException extends FreeformException
{
}
