<?php

namespace Solspace\Addons\FreeformNext\Library\Exceptions\DataObjects;

use Solspace\Addons\FreeformNext\Library\Exceptions\FreeformException;

class EmailTemplateException extends FreeformException
{
}
