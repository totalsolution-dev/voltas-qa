<?php

namespace Solspace\Addons\FreeformNext\Library\Composer\Components\Fields\Interfaces;

interface MultiDimensionalValueInterface
{
}
