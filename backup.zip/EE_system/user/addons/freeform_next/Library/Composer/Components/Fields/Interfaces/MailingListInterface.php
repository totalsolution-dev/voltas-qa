<?php
/**
 * Freeform for ExpressionEngine
 *
 * @package       Solspace:Freeform
 * @author        Solspace, Inc.
 * @copyright     Copyright (c) 2008-2019, Solspace, Inc.
 * @link          https://docs.solspace.com/expressionengine/freeform/v1/
 * @license       https://docs.solspace.com/license-agreement/
 */

namespace Solspace\Addons\FreeformNext\Library\Composer\Components\Fields\Interfaces;

interface MailingListInterface
{
    /**
     * @return int
     */
    public function getIntegrationId();

    /**
     * @return string
     */
    public function getResourceId();

    /**
     * @return string
     */
    public function getEmailFieldHash();
}
