<?php

/**
 * Created by PhpStorm.
 * User: codeno
 * Date: 17.15.11
 * Time: 15:04
 */
class NextFieldObject
{

}