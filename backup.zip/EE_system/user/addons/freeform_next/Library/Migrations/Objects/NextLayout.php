<?php

namespace Solspace\Addons\FreeformNext\Library\Migrations\Objects;

class NextLayout
{
    public $name;
}